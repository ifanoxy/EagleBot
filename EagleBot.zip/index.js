/**
 * @author Ifanoxy#7183
 */
const { EagleClient } = require("./structures/Client");
new EagleClient();