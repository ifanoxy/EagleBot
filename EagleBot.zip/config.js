module.exports = {
    discord: {
        token: "MTA1NzAwODAwMDEzMDM2NzU5MQ.G8hc_M.9c68JSImeoAzhm5bKyCqeFSVNhdzc_9HxPZy6w"
    },
    database: {
        name: "",
        username: "",
        password: "",
    },
    webhook: {
        token: "_Mx2P12-QuqxifynC7yB-ZxX3y6ArJO8yWo0CzKi6acH6KlCT8F15Moi7eHeEIDuClfy",
        id: "1057017269005328494",
    },
    ownerId: "429345463494508554"
}