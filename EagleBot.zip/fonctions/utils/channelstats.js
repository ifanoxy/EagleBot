const { ChannelType } = require("discord.js")

module.exports = {
    name: "channelstats",
    repeat: true,
    async execute(client) {
        const statsData = client.managers.statsManager.map(m => m.values)
        for (let guildData of statsData) {
            const guild = client.guilds.cache.get(guildData.guildId);
            if (!guild) continue;
            for (let channelStats of guildData.data) {
                switch (channelStats.type) {
                    case "Channels_All" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Channels Totaux: ${guild.channels.cache.size}`,
                        })
                    }break;
                    case "Channels_Text" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Channels Textuels: ${guild.channels.cache.filter(c => c.type == ChannelType.GuildText).size}`,
                        })
                    }break;
                    case "Channels_Voice" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Channels Vocaux: ${guild.channels.cache.filter(c => c.type == ChannelType.GuildVoice).size}`,
                        })
                    }break;
                    case "Roles_All" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Roles Totaux: ${guild.roles.cache.size}`,
                        })
                    }break;
                    case "Roles_Members" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `${await guild.roles.cache.get(channelStats.roleId)?.name}: ${guild.roles.cache.get(channelStats.roleId)?.members.size}`,
                        })
                    }break;
                    case "Members_All" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Utilisateurs: ${guild.members.cache.size}`
                        })
                    }break;
                    case "Members_Humans" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Membres: ${guild.members.cache.filter(m => !m.user.bot).size}`
                        })
                    }break;
                    case "Members_Bots" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Bots: ${guild.members.cache.filter(m => m.user.bot).size}`,
                        })
                    }break;
                    case "Voice_All" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Membres en vocal: ${guild.members.cache.filter(m => m.voice.channel).size}`,
                        })
                    }break;
                    case "Status_Online" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Membres en ligne: ${await guild.members.fetch().then(data => data.filter(x => x.presence?.status == "online").size)}/${guild.members.cache.size}`,
                        })
                    }break;
                    case "Status_Offline" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Membres Inactifs: ${await guild.members.fetch().then(data => data.filter(x => x.presence?.status == "offline").size)}/${guild.members.cache.size}`,
                        })
                    }break;
                    case "Status_NotOffline" : {
                        guild.channels.cache.get(channelStats.channelId).edit({
                            name: `Membres Actifs: ${await guild.members.fetch().then(data => data.filter(x => x.presence?.status != "offline").size)}/${guild.members.cache.size}`,
                        })
                    }break;
                }
            }
        }
    }
}