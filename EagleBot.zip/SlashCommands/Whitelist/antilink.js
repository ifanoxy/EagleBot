const { SlashCommandBuilder, EmbedBuilder, CommandInteraction } = require("discord.js");
const { EagleClient } = require('../../structures/Client')

module.exports = {
    data: new SlashCommandBuilder()
    .setName("anti-link")
    .setDescription("Permet de bloquer tout les liens")
    .addBooleanOption(
        option => option.setName("activé").setDescription("Permet d'actif ou non l'anti link").setRequired(true)
    )
    .addRoleOption(
        option => option.setName("role-minimum").setDescription("Role minimum nécessaire pour envoyé des liens")
    ),
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {EagleClient} client 
     */
    execute(interaction, client) {
        let guildData = client.managers.guildsManager.getAndCreateIfNotExists(interaction.guildId, {
            guildId: interaction.guildId
        });
        guildData.anti.link = {
            roleMini: interaction.options.getRole('role-minimum').id || interaction.guild.roles.everyone,
            active: interaction.options.getBoolean('activé')
        };
        guildData.save()
        interaction.reply({
            embeds: [
                new EmbedBuilder()
                .setTitle("Anti link")
                .setDescription(`
                **status:** ${interaction.options.getBoolean('activé') ? "Activé" : "désactivé"}
                **role minimum:** ${interaction.options.getRole('role-minimum') || interaction.guild.roles.everyone}
                `)
                .setColor("Blue")   
                .setTimestamp()
            ]
        })
    }
}